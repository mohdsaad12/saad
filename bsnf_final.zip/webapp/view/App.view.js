sap.ui.jsview("bsnf_app.view.App", {

	getControllerName: function() {
		return "bsnf_app.view.App";
	},

	createContent: function(oController) {

		// to avoid scroll bars on desktop the root view must be set to block display
		this.setDisplayBlock(false);

		// load the master page
		//	var MainPage = sap.ui.xmlview("TView2", "www.lilly.com.view.pateint");

		var main = sap.ui.xmlview("position", "bsnf_app.view.position");

		main.getController().nav = this.getController();
		//this.app.addPage(master, true);		

		var oPage = new sap.m.Page({
			title: "",
			content: [main],
			footer: new sap.m.Bar()
		});

		var app = new sap.m.App("App", {
			//initialPage: "oPage"
		});

		app.addPage(oPage);
		return app;
	}
});