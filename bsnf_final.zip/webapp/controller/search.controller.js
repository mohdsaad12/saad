sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/Popover',
	'sap/m/Button',
	'sap/m/MessageBox',
	'sap/m/MessageToast'
], function(Controller, Popover, Button, MessageBox, MessageToast) {
	"use strict";
	var fromData;
	var toData;
	return Controller.extend("bsnf_app.controller.search", {
		Back_to_position: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("position");
		},
		onInit: function() {

			this.getView().byId("table1").setVisible(false);

		},

		onPressSearch: function(oEvent) {
			this.getView().byId("table1").setVisible(true);
			var vData2 = [{
					"No": "1",
					"Positiontype": "MoW",
					"HQMobile": "HQ",
					"version": "11"
				}, {
					"No": "2",
					"Positiontype": "Mechanical",
					"HQMobile": "HQ",
					"version": "12"
				}, {
					"No": "3",
					"Positiontype": "TCU",
					"HQMobile": "Mobile",
					"version": "13"
				}],

				oModel2 = new sap.ui.model.json.JSONModel(); // created a
			// JSON
			// model
			oModel2.setData({
				modelData: vData2
			});
			this.getView().byId("table1").setModel(oModel2);
			/*	this.getView().setModel(oModel2);*/

		}

	});
});