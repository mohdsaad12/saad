sap.ui.define(
	['jquery.sap.global', 'sap/m/MessageToast',
		'sap/ui/core/Fragment', 'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter', 'sap/ui/model/json/JSONModel',
		'sap/m/MessageBox', "sap/ui/model/FilterOperator"
	],
	function(jQuery, MessageToast, Fragment, Controller, Filter,
		JSONModel, MessageBox, FilterOperator) {
		"use strict";
		var value, flag;
		var CController = Controller.extend("bsnf_app.controller.create", {
			Back_to_master: function() {
			
				sap.ui.core.UIComponent.getRouterFor(this).navTo("master");
			},
			save: function(oEvent) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(
					"Are you sure you want to save?", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			},
			
		});
	});