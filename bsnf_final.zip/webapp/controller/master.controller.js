sap.ui.define(
	['jquery.sap.global', 'sap/m/MessageToast',
		'sap/ui/core/Fragment', 'sap/ui/core/mvc/Controller',
		'sap/ui/model/Filter', 'sap/ui/model/json/JSONModel',
		'sap/m/MessageBox', "sap/ui/model/FilterOperator"
	],
	function(jQuery, MessageToast, Fragment, Controller, Filter,
		JSONModel, MessageBox, FilterOperator) {
		"use strict";
		var value, flag;
		var CController = Controller.extend("bsnf_app.controller.master", {

			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf view.TView2
			 */
			onInit: function() {
				var oModel2 = new sap.ui.model.json.JSONModel(); // created a JSON model

				// define some sample data using JSON

				var vDataView2 = [{
					Request: "CARMAN APPERENTICE",
					Appliedon: "1/10/2016",
					DocumentLevelLock: "4000"

				}, {
					Request: "FACILITIES TECHNICIAN",
					Appliedon: "2/01/2016",
					DocumentLevelLock: "6000"
				}, {
					Request: "MACHINIST APPERENTICE",
					Appliedon: "10/6/2015",
					DocumentLevelLock: "5000"
				}, {
					Request: "MOBILE CONS SIG INSP",
					Appliedon: "13/9/2016",
					DocumentLevelLock: "1000"
				}];

				oModel2.setData({
					modelDataView2: vDataView2
				});

				this.getView().byId("oh2").setModel(oModel2);

				if (flag == 1) {
					oModel2 = new sap.ui.model.json.JSONModel();

					var vData = [{
						Request: "CARMAN APPERENTICE",
						Appliedon: "Friday,27th January",

					}]

					var oModel = new sap.ui.model.json.JSONModel(); // created
					// a
					// JSON
					// model
					oModel.setData({
						modelData: vData
					});

					this.getView().byId("oh1").setModel(oModel);
				} else if (flag == 2) {
					oModel2 = new sap.ui.model.json.JSONModel();

					var vData = [{
						Request: "FACILITIES TECHNICIAN",

						Appliedon: "Thursday,26th Jan",

					}]

					var oModel = new sap.ui.model.json.JSONModel(); // created
					// a
					// JSON
					// model
					oModel.setData({
						modelData: vData
					});

					this.getView().byId("oh1").setModel(oModel);
				} else if (flag == 3) {

					oModel2 = new sap.ui.model.json.JSONModel();

					var vData = [{
						Request: "MACHINIST APPERENTICE",

						Appliedon: "Monday,23rd Jan",

					}]

					var oModel = new sap.ui.model.json.JSONModel(); // created
					// a
					// JSON
					// model
					oModel.setData({
						modelData: vData
					});

					this.getView().byId("oh1").setModel(oModel);
				} else if (flag == 4) {
					oModel2 = new sap.ui.model.json.JSONModel();

					var vData = [{
						Request: "MOBILE CONS SIG INSP",

						Appliedon: "Saturday,28th Jan",

					}]

					var oModel = new sap.ui.model.json.JSONModel(); // created
					// a
					// JSON
					// model
					oModel.setData({
						modelData: vData
					});

					this.getView().byId("oh1").setModel(oModel);
				} else {
					oModel2 = new sap.ui.model.json.JSONModel();

					var vData = [{
						Request: "CARMAN APPERENTICE",

						Appliedon: "Friday,27th January",

					}]

					var oModel = new sap.ui.model.json.JSONModel(); // created
					// a
					// JSON
					// model
					oModel.setData({
						modelData: vData
					});

					this.getView().byId("oh1").setModel(oModel);
				}

			},

			onPressNavToDetail: function(oEvent) {
				this.getSplitContObj().to(this.createId("detailDetail"));
			},
			onListItemPress: function(oEvent) {
				// The actual Item
				var oItem = oEvent.getSource().getBindingContext().getObject().Request;
				if (oItem == "CARMAN APPERENTICE") {
					flag = 1;
					this.onInit();
				} else if (oItem == "FACILITIES TECHNICIAN") {
					flag = 2;
					this.onInit();
				} else if (oItem == "MACHINIST APPERENTICE") {
					flag = 3;
					this.onInit();
				} else if (oItem == "MOBILE CONS SIG INSP") {
					flag = 4;
					this.onInit();
				}
			},
			Back_to_position: function() {
				sap.ui.core.UIComponent.getRouterFor(this).navTo("position");
			},
			create: function() {
				sap.ui.core.UIComponent.getRouterFor(this).navTo("create");
			},
			onPressDetailBack: function() {
				this.getSplitContObj().backDetail();
			},

			onPressMasterBack: function() {
				this.getSplitContObj().backMaster();
			},

			onPressGoToMaster: function() {
				this.getSplitContObj().toMaster(this.createId("master2"));
			},

			onOrientationChange: function(oEvent) {
				var bLandscapeOrientation = oEvent.getParameter("landscape"),
					sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
				MessageToast.show(sMsg, {
					duration: 5000
				});
			},

			onPressModeBtn: function(oEvent) {
				var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

				this.getSplitContObj().setMode(sSplitAppMode);
				//	MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {duration: 5000});
			},
			
			edit: function (evt) {
			if (evt.getSource().getPressed()) {
				this.getView().byId("name").setEditable(true);
				this.getView().byId("DP1").setEditable(true);
				this.getView().byId("DP2").setEditable(true);
				this.getView().byId("s").setEditable(true);
				this.getView().byId("con").setEditable(true);
				this.getView().byId("grp").setEditable(true);
				this.getView().byId("dep").setEditable(true);
				this.getView().byId("pos").setEditable(true);
				this.getView().byId("st").setEditable(true);
				this.getView().byId("hof").setEditable(true);
				this.getView().byId("sh").setEditable(true);
				this.getView().byId("mt").setEditable(true);
				this.getView().byId("ot").setEditable(true);
				this.getView().byId("un").setEditable(true);
				this.getView().byId("gr").setEditable(true);
				this.getView().byId("dep2").setEditable(true);
				this.getView().byId("po").setEditable(true);
				this.getView().byId("sta").setEditable(true);
				this.getView().byId("lo").setEditable(true);
				this.getView().byId("gru").setEditable(true);
				this.getView().byId("shi").setEditable(true);
				this.getView().byId("emp").setEditable(true);
				this.getView().byId("sup").setEditable(true);
				this.getView().byId("mc").setEditable(true);
				this.getView().byId("cc").setEditable(true);
				this.getView().byId("dis").setEditable(true);
				this.getView().byId("prd").setEditable(true);
				this.getView().byId("at").setEditable(true);
				this.getView().byId("sd").setEditable(true);
				this.getView().byId("sti").setEditable(true);
				this.getView().byId("ed").setEditable(true);
				this.getView().byId("et").setEditable(true);
				this.getView().byId("ar").setEditable(true);
				this.getView().byId("en").setEditable(true);
				this.getView().byId("eid").setEditable(true);
				this.getView().byId("sda").setEditable(true);
				this.getView().byId("ft").setEditable(true);
				this.getView().byId("ata").setEditable(true);
				this.getView().byId("sdb").setEditable(true);
				this.getView().byId("stic").setEditable(true);
				this.getView().byId("edd").setEditable(true);
				this.getView().byId("ete").setEditable(true);
				this.getView().byId("arf").setEditable(true);
				this.getView().byId("eng").setEditable(true);
				this.getView().byId("eidh").setEditable(true);
				this.getView().byId("sdai").setEditable(true);
				this.getView().byId("ftj").setEditable(true);
			} else {
				this.getView().byId("name").setEditable(false);
				this.getView().byId("DP1").setEditable(false);
				this.getView().byId("DP2").setEditable(false);
				this.getView().byId("s").setEditable(false);
				this.getView().byId("con").setEditable(false);
				this.getView().byId("grp").setEditable(false);
				this.getView().byId("dep").setEditable(false);
				this.getView().byId("pos").setEditable(false);
				this.getView().byId("st").setEditable(false);
				this.getView().byId("hof").setEditable(false);
				this.getView().byId("sh").setEditable(false);
				this.getView().byId("mt").setEditable(false);
				this.getView().byId("ot").setEditable(false);
				this.getView().byId("un").setEditable(false);
				this.getView().byId("gr").setEditable(false);
				this.getView().byId("dep1").setEditable(false);
				this.getView().byId("po").setEditable(false);
				this.getView().byId("sta").setEditable(false);
				this.getView().byId("lo").setEditable(false);
				this.getView().byId("gru").setEditable(false);
				this.getView().byId("shi").setEditable(false);
				this.getView().byId("emp").setEditable(false);
				this.getView().byId("sup").setEditable(false);
				this.getView().byId("mc").setEditable(false);
				this.getView().byId("cc").setEditable(false);
				this.getView().byId("dis").setEditable(false);
				this.getView().byId("prd").setEditable(false);
				this.getView().byId("at").setEditable(false);
				this.getView().byId("sd").setEditable(false);
				this.getView().byId("sti").setEditable(false);
				this.getView().byId("ed").setEditable(false);
				this.getView().byId("et").setEditable(false);
				this.getView().byId("ar").setEditable(false);
				this.getView().byId("en").setEditable(false);
				this.getView().byId("eid").setEditable(false);
				this.getView().byId("sda").setEditable(false);
				this.getView().byId("ft").setEditable(false);
				this.getView().byId("ata").setEditable(false);
				this.getView().byId("sdb").setEditable(false);
				this.getView().byId("stic").setEditable(false);
				this.getView().byId("edd").setEditable(false);
				this.getView().byId("ete").setEditable(false);
				this.getView().byId("arf").setEditable(false);
				this.getView().byId("eng").setEditable(false);
				this.getView().byId("eidh").setEditable(false);
				this.getView().byId("sdai").setEditable(false);
				this.getView().byId("ftj").setEditable(false);
			};
		},
			
			cancel: function(oEvent) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(
					"Are you sure you want to cancel?", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			},
			save: function(oEvent) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.confirm(
					"Are you sure you want to save?", {
						styleClass: bCompact ? "sapUiSizeCompact" : ""
					}
				);
			},

			getSplitContObj: function() {
				var result = this.byId("SplitContDemo");
				if (!result) {
					jQuery.sap.log.error("SplitApp object can't be found");
				}
				return result;
			}

		});
	});