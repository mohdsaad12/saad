sap.ui.define([
	'jquery.sap.global',
	'sap/ui/core/mvc/Controller',
	'sap/ui/model/json/JSONModel',
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(jQuery, Controller, JSONModel, MessageToast, MessageBox) {
	"use strict";
	var flag;
	var WizardController = Controller.extend("bsnf_app.controller.bulletin", {
		onInit: function() {


			this.oFilterBar = null;
			var sViewId = this.getView().getId();

			this.oFilterBar = sap.ui.getCore().byId(sViewId + "--filterBar");

			this.oFilterBar.registerFetchData(this.fFetchData);
			this.oFilterBar.registerApplyData(this.fApplyData);
			this.oFilterBar.registerGetFiltersWithValues(this.fGetFiltersWithValues);

			this.fVariantStub();

			this.onToggleSearchField();

			this.oFilterBar.fireInitialise();

			this._sHeader = this.oFilterBar.getHeader();

			this._wizard = this.getView().byId("CreateProductWizard");
			this._oNavContainer = this.getView().byId("wizardNavContainer");
			this._oWizardContentPage = this.getView().byId("wizardContentPage");
			this._oWizardReviewPage = sap.ui.xmlfragment("bsnf_app.fragment.header3", this);

			this._oNavContainer.addPage(this._oWizardReviewPage);
			this.model = new sap.ui.model.json.JSONModel();
			this.model.setData({
				productNameState: "Error",
				productWeightState: "Error"
			});
			this.getView().setModel(this.model);
			this.model.setProperty("/productType", "Mobile");
			this.model.setProperty("/navApiEnabled", true);
			this.model.setProperty("/productVAT", false);
			this._setEmptyValue("/productManufacturer");
			this._setEmptyValue("/productDescription");
			this._setEmptyValue("/productPrice");
		},
		Back_to_position: function() {
			sap.ui.core.UIComponent.getRouterFor(this).navTo("Position");
		},
		select :function(oEvent){
		},

		onToggleSearchField: function(oEvent) {

			var oSearchField = this.oFilterBar.getBasicSearch();
			if (!oSearchField) {
				var oBasicSearch = new sap.m.SearchField({
					showSearchButton: false
				});
			} else {
				oSearchField = null;
			}

			this.oFilterBar.setBasicSearch(oBasicSearch);
		},

		onToggleShowFilters: function(oEvent) {

			var bFlag = this.oFilterBar.getShowFilterConfiguration();
			this.oFilterBar.setShowFilterConfiguration(!bFlag);
		},

		onToggleHeader: function(oEvent) {

			var sHeader = "";
			if (this.oFilterBar.getHeader() !== this._sHeader) {
				sHeader = this._oHeader;
			}

			this.oFilterBar.setHeader(sHeader);

		},
		onChange: function(oEvent) {
			this.oFilterBar.fireFilterChange(oEvent);
		},
		onClear: function(oEvent) {
			var oItems = this.oFilterBar.getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				var oControl = this.oFilterBar.determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oControl.setValue("");
				}
			}
		},
		onReset: function(oEvent) {
			jQuery.sap.require("sap.m.MessageToast");
			var sMessage = "onReset trigered";
			sap.m.MessageToast.show(sMessage);
		},
		onSearch: function(oEvent) {
			
			var oModel2 = new sap.ui.model.json.JSONModel(); // created a JSON model

			// define some sample data using JSON

			var vDataView2 = [{
				BulletinRef: "1-Mar",
				BulletinDescription: "1879",
				BulletinReason: "400",
				BulletinCount: "0",
				BulletinStatus: "8000",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Apr",
				BulletinDescription: "678",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "4600",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-May",
				BulletinDescription: "1876",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "2566",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Jun",
				BulletinDescription: "987",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "6783",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Jul",
				BulletinDescription: "1782",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "445",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Aug",
				BulletinDescription: "654",
				BulletinReason: "0",
				BulletinCount: "876",
				BulletinStatus: "1234",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Sep",
				BulletinDescription: "1265",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "876",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}, {
				BulletinRef: "1-Oct",
				BulletinDescription: "98",
				BulletinReason: "0",
				BulletinCount: "0",
				BulletinStatus: "5678",
				EffectiveDate: "1/Mar/2017",
				TermDate: "1/May/2017"
			}];

			oModel2.setData({
				modelDataView2: vDataView2
			});

			this.getView().byId("oh2").setModel(oModel2);
			this.getView().byId("oh3").setModel(oModel2);

			oModel2 = new sap.ui.model.json.JSONModel();
		},
		fFetchData: function() {

			var sGropuName;
			var oJsonParam;
			var oJsonData = [];

			var oItems = this.getAllFilterItems(true);
			for (var i = 0; i < oItems.length; i++) {
				oJsonParam = {};
				sGroupName = null;
				if (oItems[i].getGroupName) {
					sGroupName = oItems[i].getGroupName();
					oJsonParam.group_name = sGroupName;
				}

				oJsonParam.name = oItems[i].getName();

				var oControl = this.determineControlByFilterItem(oItems[i]);
				if (oControl) {
					oJsonParam.value = oControl.getValue();
					oJsonData.push(oJsonParam);
				}
			}

			return oJsonData;
		},
		fApplyData: function(oJsonData) {

			var sGroupName;

			for (var i = 0; i < oJsonData.length; i++) {

				sGroupName = null;

				if (oJsonData[i].group_name) {
					sGroupName = oJsonData[i].group_name;
				}

				var oControl = this.determineControlByName(oJsonData[i].name, sGroupName);
				if (oControl) {
					oControl.setValue(oJsonData[i].value);
				}
			}
		},
		fGetFiltersWithValues: function() {
			var i;
			var oControl;
			var aFilters = this.getFilterGroupItems();

			var aFiltersWithValue = [];

			for (i = 0; i < aFilters.length; i++) {
				oControl = this.determineControlByFilterItem(aFilters[i]);
				if (oControl && oControl.getValue && oControl.getValue()) {
					aFiltersWithValue.push(aFilters[i]);
				}
			}

			return aFiltersWithValue;
		},
		fVariantStub: function() {
			var oVM = this.oFilterBar._oVariantManagement;
			oVM.initialise = function() {
				this.fireEvent("initialise");
				this._setStandardVariant();

				this._setSelectedVariant();
			};

			var nKey = 0;
			var mMap = {};
			var sCurrentVariantKey = null;
			oVM._oVariantSet = {

				getVariant: function(sKey) {
					return mMap[sKey];
				},
				addVariant: function(sName) {
					var sKey = "" + nKey++;

					var oVariant = {
						key: sKey,
						name: sName,
						getItemValue: function(s) {
							return this[s];
						},
						setItemValue: function(s, oObj) {
							this[s] = oObj;
						},
						getVariantKey: function() {
							return this.key;
						}
					};
					mMap[sKey] = oVariant;

					return oVariant;
				},
				setCurrentVariantKey: function(sKey) {
					sCurrentVariantKey = sKey;
				},
				getCurrentVariantKey: function() {
					return sCurrentVariantKey;
				},
				delVariant: function(sKey) {
					if (mMap[sKey]) {
						delete mMap[sKey];
					}
				}

			};
		},

		Back_to_bulletin: function() {
			this._handleMessageBoxOpen("Are you sure you want to go back?", "warning");
		},
		edit: function(evt) {
			if (evt.getSource().getPressed()) {
				var ab = this.getView().byId("br");
				this.getView().byId("bd").setEditable(true);
				this.getView().byId("bre").setEditable(true);
				this.getView().byId("bc").setEditable(true);
				this.getView().byId("bs").setEditable(true);
				this.getView().byId("ed").setEditable(true);
				this.getView().byId("td").setEditable(true);
				
			
			} else {
				
				this.getView().byId("br").setEditable(false);
				this.getView().byId("bd").setEditable(false);
				this.getView().byId("bre").setEditable(false);
				this.getView().byId("bc").setEditable(false);
				this.getView().byId("bs").setEditable(false);
				this.getView().byId("ed").setEditable(false);
				this.getView().byId("td").setEditable(false);
			};
		},

		setProductType: function(evt) {
			var productType = evt.getSource().getTitle();
			this.model.setProperty("/productType", productType);
			this.getView().byId("ProductStepChosenType").setText("Chosen product type: " + productType);
			this._wizard.validateStep(this.getView().byId("ProductTypeStep"));
		},
		setProductTypeFromSegmented: function(evt) {
			var productType = evt.mParameters.button.getText();
			this.model.setProperty("/productType", productType);
			this._wizard.validateStep(this.getView().byId("ProductTypeStep"));
		},
		additionalInfoValidation: function() {
			var name = this.getView().byId("ProductName").getValue();
			var weight = parseInt(this.getView().byId("ProductWeight").getValue());

			isNaN(weight) ? this.model.setProperty("/productWeightState", "Error") : this.model.setProperty("/productWeightState", "None");
			name.length < 6 ? this.model.setProperty("/productNameState", "Error") : this.model.setProperty("/productNameState", "None");

			this._wizard.invalidateStep(this.getView().byId("ProductInfoStep"));

			this._wizard.validateStep(this.getView().byId("ProductInfoStep"));
		},
		pricingActivate: function() {
			this.model.setProperty("/navApiEnabled", true);
		},
		pricingComplete: function() {
			this.model.setProperty("/navApiEnabled", false);
		},
		scrollFrom4to2: function() {
			this._wizard.goToStep(this.getView().byId("ProductInfoStep"));
		},
		goFrom4to3: function() {
			if (this._wizard.getProgressStep() === this.getView().byId("PricingStep"))
				this._wizard.previousStep();
		},
		goFrom5to4: function() {
			if (this._wizard.getProgressStep() === this.getView().byId("Pricing"))
				this._wizard.previousStep();
		},
		goFrom4to5: function() {
			if (this._wizard.getProgressStep() === this.getView().byId("PricingStep"))
				this._wizard.nextStep();
		},
		wizardCompletedHandler: function() {
			this._oNavContainer.to(this._oWizardReviewPage);
		},
		backToWizardContent: function() {
			this._oNavContainer.backToPage(this._oWizardContentPage.getId());
		},
		editStepOne: function() {
			this._handleNavigationToStep(0);
		},
		editStepTwo: function() {
			this._handleNavigationToStep(1);
		},
		editStepThree: function() {
			this._handleNavigationToStep(2);
		},
		editStepFour: function() {
			this._handleNavigationToStep(3);
		},
		_handleNavigationToStep: function(iStepNumber) {
			var that = this;

			function fnAfterNavigate() {
				that._wizard.goToStep(that._wizard.getSteps()[iStepNumber]);
				that._oNavContainer.detachAfterNavigate(fnAfterNavigate);
			}

			this._oNavContainer.attachAfterNavigate(fnAfterNavigate);
			this.backToWizardContent();
		},
		_handleMessageBoxOpen: function(sMessage, sMessageBoxType) {
			var that = this;
			MessageBox[sMessageBoxType](sMessage, {
				actions: [MessageBox.Action.YES, MessageBox.Action.NO],
				onClose: function(oAction) {
					if (oAction === MessageBox.Action.YES) {
						that._handleNavigationToStep(0);
						that._wizard.discardProgress(that._wizard.getSteps()[0]);
					}
				},
			});
		},
		_setEmptyValue: function(sPath) {
			this.model.setProperty(sPath, "n/a");
		},
		handleWizardCancel: function() {
			this._handleMessageBoxOpen("Are you sure you want to cancel your report?", "warning");
		},
		handleWizardSubmit: function() {
			this._handleMessageBoxOpen("Are you sure you want to submit your report?", "confirm");
		},
		productWeighStateFormatter: function(val) {
			return isNaN(val) ? "Error" : "None";
		},
		discardProgress: function() {
			this._wizard.discardProgress(this.getView().byId("ProductTypeStep"));

			var clearContent = function(content) {
				for (var i = 0; i < content.length; i++) {
					if (content[i].setValue) {
						content[i].setValue("");
					}

					if (content[i].getContent) {
						clearContent(content[i].getContent());
					}
				}
			};

			this.model.setProperty("/productWeightState", "Error");
			this.model.setProperty("/productNameState", "Error");
			clearContent(this._wizard.getSteps());
		}
	});

	return WizardController;
});