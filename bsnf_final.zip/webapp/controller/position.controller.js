sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("bsnf_app.controller.position", {
		onInit: function() {/*
		app.setBackgroundImage("images/demo/nature/huntingLeopard.jpg");
							app.setBackgroundColor("");*/
		},
			navigate_to_Master: function(oEvent){
			sap.ui.core.UIComponent.getRouterFor(this).navTo("master");
				
			},
			navigate_to_search: function(oEvent){
			sap.ui.core.UIComponent.getRouterFor(this).navTo("search");
				
			},
			navigate_to_bullet: function(oEvent){
			sap.ui.core.UIComponent.getRouterFor(this).navTo("bulletin");
				
			}
	});
});